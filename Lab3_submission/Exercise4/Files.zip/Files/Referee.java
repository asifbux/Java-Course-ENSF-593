import java.util.Scanner;

/**
 * Provide data members and methods to create a refree object for tic-tac-toe 
 * board game in a Java application.
 * The overall purpose of this class exercise is to illustrate how tic-tac-toe referee is created and this referee communicates with the player and its opponent to control the game.
 * @author Asif Bux
 * @version 1.0
 * @since October 4, 2019
 */
public class Referee {
	
	/** The x player object. */
	Player xPlayer;
	
	/** The o player object. */
	Player oPlayer;
	
	/** The board object. */
	Board board;
	
	/**
	 * Instantiates a new referee.
	 */
	public Referee() {
		
	}
	
	/**
	 * Run the game by setting the player and its opponent and calling the start of the game.
	 */
	public void runTheGame() {
		//setOpponent of Player class to setX and setO players
		xPlayer.setOpponent(oPlayer);
		oPlayer.setOpponent(xPlayer);
		System.out.println("Referee started the game");
		board.display();
		
		while (true) {
			xPlayer.play();
			oPlayer.play();
		}
		
	}
	
	/**
	 * Sets the board to this referee object.
	 *
	 * @param board the new board
	 */
	public void setBoard(Board board) {
		this.board = board;
		
	}
	
	/**
	 * Sets the o player object.
	 *
	 * @param oPlayer the new o player
	 */
	public void setoPlayer(Player oPlayer) {
		
		this.oPlayer = oPlayer;
		
	}
	
	/**
	 * Sets the x player object.
	 *
	 * @param xPlayer the new x player
	 */
	public void setxPlayer(Player xPlayer) {
		
		this.xPlayer = xPlayer;
		
	}
	
}
